document.addEventListener('DOMContentLoaded', function () {
   const langBtn = document.querySelector('.content__lang-btn');
   const enBlocks = document.querySelector('.content__block-col--en');
   const ruBlocks = document.querySelector('.content__block-col--ru');

    langBtn.addEventListener('click', function () {
            const lang = this.dataset.lang;
            const textBtn = this.querySelector('.content__lang-text');
            const iconBtn = this.querySelector('.content__lang-icon');

            if(lang === 'ru') {
                textBtn.innerHTML = 'in English';
                iconBtn.innerHTML = '<use xlink:href="#icon-en"></use>';
                this.dataset.lang = 'en';
                enBlocks.classList.add('hidden');
                enBlocks.classList.remove('show');
                ruBlocks.classList.add('show');

            } else if (lang === 'en') {
                textBtn.innerHTML = 'на русском';
                iconBtn.innerHTML = '<use xlink:href="#icon-ru"></use>';
                this.dataset.lang = 'ru';
                enBlocks.classList.add('show');
                ruBlocks.classList.add('hidden');
                ruBlocks.classList.remove('show');
            }
    });


});